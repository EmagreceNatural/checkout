(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_4f6948b3._.js",
  "static/chunks/node_modules__pnpm_13907add._.js"
],
    source: "dynamic"
});
