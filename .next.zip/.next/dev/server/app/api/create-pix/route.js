var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/create-pix/route.js")
R.c("server/chunks/f0026_next_c40ff2bd._.js")
R.c("server/chunks/[root-of-the-server]__2454f17e._.js")
R.c("server/chunks/_next-internal_server_app_api_create-pix_route_actions_ae289464.js")
R.m("[project]/node_modules/.pnpm/next@16.0.0_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/create-pix/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/.pnpm/next@16.0.0_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/create-pix/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
