"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Check, Copy } from "lucide-react"
import Image from "next/image"

interface PixResultProps {
  pixData: {
    qrCode: string
    qrCodeImage: string
    txid: string
    amount: number
    expiresAt?: string
  }
  onNewPayment: () => void
}

export function PixResult({ pixData, onNewPayment }: PixResultProps) {
  const [copied, setCopied] = useState(false)

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(pixData.qrCode)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    } catch (err) {
      console.error("Erro ao copiar:", err)
    }
  }

  return (
    <div className="w-full max-w-md mx-auto bg-white">
      {/* Main Content */}
      <div className="p-6 space-y-6">
        {/* Success Message */}
        <div className="text-center space-y-2">
          <h2 className="text-2xl font-bold text-gray-800">PIX Gerado com Sucesso!</h2>
          <p className="text-lg text-gray-700">
            Valor: <span className="font-bold text-gray-900">R$ {pixData.amount.toFixed(2)}</span>
          </p>
        </div>

        {/* QR Code Section - Subtle Gray Layout */}
        <div className="bg-gray-100 rounded-lg p-6 space-y-4 border border-gray-200">
          {/* QR Code Image */}
          <div className="flex justify-center">
            <div className="bg-white rounded-lg p-4 shadow-lg">
              <Image
                src={pixData.qrCodeImage || "/placeholder.svg"}
                alt="QR Code PIX"
                width={300}
                height={300}
                className="w-full h-auto"
                unoptimized
              />
            </div>
          </div>

          {/* Instructions */}
          <div className="text-gray-700 text-center space-y-2">
            <h3 className="font-bold text-lg text-gray-900">Como pagar:</h3>
            <ol className="text-sm space-y-1">
              <li>1. Abra o app do seu banco</li>
              <li>2. Escolha pagar com PIX</li>
              <li>3. Escaneie o QR Code acima</li>
              <li>4. Confirme o pagamento</li>
            </ol>
          </div>
        </div>

        {/* Copy PIX Code Section */}
        <div className="space-y-3">
          <h3 className="font-semibold text-gray-900 text-center">Ou copie o código PIX:</h3>

          {/* Large Copy Button */}
          <Button
            onClick={handleCopy}
            className="w-full h-14 bg-gray-700 hover:bg-gray-800 text-white font-bold text-lg rounded-lg flex items-center justify-center gap-2"
          >
            {copied ? (
              <>
                <Check className="h-6 w-6" />
                Código Copiado!
              </>
            ) : (
              <>
                <Copy className="h-6 w-6" />
                Copiar Código PIX
              </>
            )}
          </Button>

          {/* PIX Code Display */}
          <div className="bg-gray-100 rounded-lg p-4 border-2 border-gray-300">
            <p className="text-xs font-mono break-all text-gray-700 text-center leading-relaxed">{pixData.qrCode}</p>
          </div>
        </div>

        {/* Transaction Info */}
        {pixData.expiresAt && (
          <div className="text-center text-sm text-gray-600">
            <p>Válido até: {new Date(pixData.expiresAt).toLocaleString("pt-BR")}</p>
          </div>
        )}

        <div className="text-center text-xs text-gray-500">ID da transação: {pixData.txid}</div>

        {/* New Payment Button */}
        <Button
          onClick={onNewPayment}
          variant="outline"
          className="w-full h-12 border-2 border-gray-400 text-gray-700 hover:bg-gray-100 font-semibold rounded-lg bg-transparent"
        >
          Fazer Nova Contribuição
        </Button>
      </div>
    </div>
  )
}
