"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Checkbox } from "@/components/ui/checkbox"
import { PixResult } from "@/components/pix-result"
import { Loader2 } from "lucide-react"
import Image from "next/image"

const MINIMUM_AMOUNT = 10.0
const QUICK_AMOUNTS = [10, 20, 50, 100, 250]

const DEFAULT_EMAIL = "emagrecenatural@gmail.com"
const DEFAULT_PHONE = "11991560063"
const DEFAULT_DOCUMENT = "43887057481"

const EXTRAS = [
  {
    id: "lottery",
    icon: "/icon-lottery.png",
    title: "3 números da sorte",
    description: "Você é quem criou a vaquinha concorrem ao sorteio de R$ 15.000,00 do Vakinha Premiada",
    price: 0,
    label: "Grátis",
  },
  {
    id: "hearts",
    icon: "/icon-heart.png",
    title: "3 Corações",
    description: "Destaquem essa vaquinha na plataforma",
    price: 3.99,
  },
  {
    id: "pet",
    icon: "/icon-pet.png",
    title: "Vakinha Pet RJ",
    description:
      "Você ajuda as ONGs G.A.R.R.A e Indefesos, dedicadas ao resgate, tratamento, reabilitação e adoção de animais em situação de vulnerabilidade.",
    price: 2.0,
  },
]

interface PixResponse {
  qrCode: string
  qrCodeImage: string
  txid: string
  amount: number
  expiresAt?: string
}

export function PixCheckout() {
  const [name, setName] = useState("")
  const [isAnonymous, setIsAnonymous] = useState(false)
  const [amount, setAmount] = useState("")
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [pixData, setPixData] = useState<PixResponse | null>(null)
  const [selectedExtras, setSelectedExtras] = useState<string[]>([])

  const amountValue = Number.parseFloat(amount) || 0
  const extrasTotal = selectedExtras.reduce((sum, extraId) => {
    const extra = EXTRAS.find((e) => e.id === extraId)
    return sum + (extra?.price || 0)
  }, 0)
  const totalAmount = amountValue + extrasTotal

  const handleAmountChange = (value: string) => {
    const sanitized = value.replace(/[^\d,.]/g, "").replace(",", ".")
    setAmount(sanitized)
    setError(null)
  }

  const handleQuickAmount = (value: number) => {
    setAmount(value.toFixed(2))
    setError(null)
  }

  const toggleExtra = (extraId: string) => {
    setSelectedExtras((prev) => (prev.includes(extraId) ? prev.filter((id) => id !== extraId) : [...prev, extraId]))
  }

  const handleGeneratePix = async () => {
    const finalName = isAnonymous ? "João Lucas" : name.trim()

    if (!finalName) {
      setError("Por favor, insira seu nome completo")
      return
    }

    if (!amountValue || amountValue < MINIMUM_AMOUNT) {
      setError(`Valor da contribuição deve ser no mínimo R$ ${MINIMUM_AMOUNT.toFixed(2)}`)
      return
    }

    setLoading(true)
    setError(null)

    try {
      const utmParams: string[] = []

      // 1. Capture from URL parameters
      const urlParams = new URLSearchParams(window.location.search)
      const utmKeys = ["src", "sck", "utm_source", "utm_campaign", "utm_medium", "utm_content", "utm_term"]

      utmKeys.forEach((key) => {
        const value = urlParams.get(key)
        if (value) {
          utmParams.push(`${key}=${encodeURIComponent(value)}`)
          console.log(`[v0] Captured from URL - ${key}: ${value}`)
        }
      })

      // 2. Try to get utmify_id from localStorage (set by UTMify pixel)
      try {
        const utmifyId =
          localStorage.getItem("utmify_id") || localStorage.getItem("_utmify_id") || localStorage.getItem("utmifyId")
        if (utmifyId) {
          utmParams.push(`src=${encodeURIComponent(utmifyId)}`)
          console.log(`[v0] Captured from localStorage - src: ${utmifyId}`)
        }
      } catch (e) {
        console.log("[v0] Could not access localStorage:", e)
      }

      // 3. Try to get all localStorage items that start with utm or utmify
      try {
        for (let i = 0; i < localStorage.length; i++) {
          const key = localStorage.key(i)
          if (key && (key.startsWith("utm") || key.startsWith("_utm"))) {
            const value = localStorage.getItem(key)
            if (value) {
              const cleanKey = key.replace(/^_/, "")
              utmParams.push(`${cleanKey}=${encodeURIComponent(value)}`)
              console.log(`[v0] Captured from localStorage - ${cleanKey}: ${value}`)
            }
          }
        }
      } catch (e) {
        console.log("[v0] Could not scan localStorage:", e)
      }

      // 4. Try to get data from Utmify SDK
      if ((window as any).Utmify?.getData) {
        try {
          const utmifyData = (window as any).Utmify.getData()
          console.log("[v0] Utmify.getData() response:", utmifyData)
          if (utmifyData && typeof utmifyData === "object") {
            Object.entries(utmifyData).forEach(([key, value]) => {
              if (value) {
                utmParams.push(`${key}=${encodeURIComponent(String(value))}`)
                console.log(`[v0] Captured from Utmify SDK - ${key}: ${value}`)
              }
            })
          }
        } catch (e) {
          console.log("[v0] Could not get Utmify.getData():", e)
        }
      }

      const utmDataString = utmParams.join("&")

      console.log("[v0] ========================================")
      console.log("[v0] 📊 UTM CAPTURE SUMMARY")
      console.log("[v0] ========================================")
      console.log("[v0] UTM Data String:", utmDataString)
      console.log("[v0] UTM Params captured:", utmParams.length, "parameters")
      console.log("[v0] Individual params:", utmParams)
      console.log("[v0] ========================================")

      const response = await fetch("/api/create-pix", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          amount: totalAmount,
          name: finalName,
          email: DEFAULT_EMAIL,
          phone: DEFAULT_PHONE,
          document: DEFAULT_DOCUMENT,
          utmData: utmDataString,
        }),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Erro ao gerar PIX")
      }

      console.log("[v0] PIX generated successfully:", data.txid)

      setPixData(data)
    } catch (err) {
      setError(err instanceof Error ? err.message : "Erro ao gerar PIX")
    } finally {
      setLoading(false)
    }
  }

  const handleNewPayment = () => {
    setPixData(null)
    setName("")
    setIsAnonymous(false)
    setAmount("")
    setError(null)
    setSelectedExtras([])
  }

  if (pixData) {
    return <PixResult pixData={pixData} onNewPayment={handleNewPayment} />
  }

  return (
    <div className="w-full max-w-md mx-auto bg-white">
      {/* Header with Logo */}
      <div className="bg-white border-b border-gray-200 py-4 px-6 flex items-center justify-between">
        <div className="relative w-32 h-10">
          <Image
            src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-rkUQGDTZxCS7JWameyranLapOiWFCS.png"
            alt="Vakinha"
            fill
            className="object-contain object-left"
          />
        </div>
        <div className="flex items-center gap-4">
          <button className="text-[#00c853] hover:text-[#00b248]">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
              />
            </svg>
          </button>
          <button className="text-gray-700 hover:text-gray-900">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
            </svg>
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="p-6 space-y-6">
        {/* Title Section */}
        <div className="space-y-2">
          <h1 className="text-gray-900 text-xl font-bold leading-tight">Doe amor, doe esperança ❤️</h1>
        </div>

        {/* Customer Data Fields */}
        <div className="space-y-4">
          <div className="space-y-2">
            <label className="text-sm font-semibold text-gray-900">Nome completo</label>
            <Input
              type="text"
              placeholder="Insira seu nome de registro"
              value={name}
              onChange={(e) => setName(e.target.value)}
              disabled={isAnonymous}
              className="text-base h-12 border-2 border-gray-300 focus:border-gray-400 rounded-lg disabled:opacity-50 disabled:cursor-not-allowed"
            />
          </div>

          {/* Anonymous donation checkbox */}
          <div className="flex items-center gap-3">
            <Checkbox
              id="anonymous"
              checked={isAnonymous}
              onCheckedChange={(checked) => setIsAnonymous(checked as boolean)}
              className="border-2 border-gray-300 data-[state=checked]:bg-[#00c853] data-[state=checked]:border-[#00c853]"
            />
            <label htmlFor="anonymous" className="text-sm font-medium text-gray-700 cursor-pointer select-none">
              Quero comprar de forma anônima
            </label>
          </div>
        </div>

        {/* Amount Input */}
        <div className="space-y-2">
          <label className="text-sm font-semibold text-gray-900">Valor da contribuição</label>
          <div className="relative">
            <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-700 font-medium text-lg">R$</span>
            <Input
              type="text"
              placeholder="0,00"
              value={amount}
              onChange={(e) => handleAmountChange(e.target.value)}
              className={`pl-14 text-lg font-medium h-14 border-2 ${
                error ? "border-red-500" : "border-gray-300"
              } focus:border-gray-400 rounded-lg`}
            />
          </div>
          {error && <p className="text-sm text-red-600 font-medium">{error}</p>}
        </div>

        <div className="flex gap-2 flex-wrap">
          {QUICK_AMOUNTS.map((value) => (
            <Button
              key={value}
              type="button"
              variant="outline"
              onClick={() => handleQuickAmount(value)}
              className="flex-1 min-w-[70px] h-10 border-2 border-gray-300 hover:border-[#00c853] hover:bg-[#00c853] hover:text-white font-semibold text-sm rounded-lg transition-colors"
            >
              R$ {value}
            </Button>
          ))}
        </div>

        <div className="space-y-2">
          <label className="text-sm font-semibold text-gray-900">Forma de pagamento</label>
          <div className="flex items-center gap-2 p-3 bg-[#e8f5e9] border-2 border-[#00c853] rounded-lg">
            <div className="w-6 h-6 rounded-full bg-[#00c853] flex items-center justify-center">
              <div className="w-3 h-3 rounded-full bg-white" />
            </div>
            <span className="font-semibold text-[#00c853]">Pix</span>
          </div>
        </div>

        <div className="bg-[#e8f5e9] rounded-lg p-4 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Checkbox
                id="turbine-all"
                checked={selectedExtras.length === EXTRAS.length}
                onCheckedChange={(checked) => {
                  if (checked) {
                    setSelectedExtras(EXTRAS.map((e) => e.id))
                  } else {
                    setSelectedExtras([])
                  }
                }}
                className="border-2 border-[#00c853] data-[state=checked]:bg-[#00c853]"
              />
              <label
                htmlFor="turbine-all"
                className="font-bold text-white bg-[#00c853] px-3 py-1 rounded-full text-sm cursor-pointer"
              >
                ADICIONE MAIS VALOR
              </label>
            </div>
            <span className="text-sm font-semibold text-gray-700">+R$ {extrasTotal.toFixed(2)}</span>
          </div>

          {EXTRAS.map((extra) => {
            const isSelected = selectedExtras.includes(extra.id)
            return (
              <div key={extra.id} className="flex items-start gap-3 bg-white rounded-lg p-3">
                <div className="flex-shrink-0 mt-1">
                  <div className="w-10 h-10 relative">
                    <Image src={extra.icon || "/placeholder.svg"} alt={extra.title} fill className="object-contain" />
                  </div>
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex-1">
                      <h3 className="font-semibold text-sm text-gray-900">{extra.title}</h3>
                      <p className="text-xs text-gray-600 mt-1 leading-relaxed">{extra.description}</p>
                    </div>
                    <div className="flex-shrink-0 flex items-center gap-2">
                      <span className="text-sm font-semibold text-gray-700">
                        {extra.label || `R$ ${extra.price.toFixed(2)}`}
                      </span>
                      <Checkbox
                        checked={isSelected}
                        onCheckedChange={() => toggleExtra(extra.id)}
                        className="border-2 border-[#00c853] data-[state=checked]:bg-[#00c853]"
                      />
                    </div>
                  </div>
                </div>
              </div>
            )
          })}
        </div>

        <div className="space-y-2 text-sm text-gray-600 border-t border-gray-200 pt-4">
          <div className="flex justify-between">
            <span>Contribuição:</span>
            <span>R$ {amountValue.toFixed(2)}</span>
          </div>
          {extrasTotal > 0 && (
            <div className="flex justify-between text-[#00c853]">
              <span>Extras:</span>
              <span>R$ {extrasTotal.toFixed(2)}</span>
            </div>
          )}
          <div className="flex justify-between font-bold text-gray-900 text-lg pt-2 border-t border-gray-200">
            <span>Total:</span>
            <span>R$ {totalAmount.toFixed(2)}</span>
          </div>
        </div>

        {/* Security Badge */}
        <div className="flex items-center gap-3 py-4">
          <div className="flex-shrink-0">
            <div className="w-12 h-12 bg-[#00c853] rounded-lg flex items-center justify-center">
              <svg className="w-6 h-6 text-white" fill="currentColor" viewBox="0 0 20 20">
                <path
                  fillRule="evenodd"
                  d="M2.166 4.999A11.954 11.954 0 0010 1.944 11.954 11.954 0 0017.834 5c.11.65.166 1.32.166 2.001 0 5.225-3.34 9.67-8 11.317C5.34 16.67 2 12.225 2 7c0-.682.057-1.35.166-2.001zm11.541 3.708a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                  clipRule="evenodd"
                />
              </svg>
            </div>
          </div>
          <div className="text-sm">
            <span className="text-gray-900">Garantimos uma </span>
            <span className="font-semibold text-gray-900">experiência segura</span>
            <span className="text-gray-900"> para todos os nossos doadores.</span>
          </div>
        </div>

        {/* Submit Button */}
        <Button
          onClick={handleGeneratePix}
          disabled={loading}
          className="w-full bg-[#00c853] hover:bg-[#00b248] text-white font-bold h-14 text-lg rounded-lg"
        >
          {loading ? (
            <>
              <Loader2 className="mr-2 h-5 w-5 animate-spin" />
              Processando...
            </>
          ) : (
            "CONTRIBUIR"
          )}
        </Button>
      </div>
    </div>
  )
}
