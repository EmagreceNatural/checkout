import { type NextRequest, NextResponse } from "next/server"

const UTMIFY_API_TOKEN = "RdkidYJtAZkF4kmdNi7USxBNCUxAFWSatTQJ"

function extractUtmParamsRobust(utmDataString: string): Record<string, string | null> {
  const trackingParameters: Record<string, string | null> = {
    src: null,
    sck: null,
    utm_source: null,
    utm_campaign: null,
    utm_medium: null,
    utm_content: null,
    utm_term: null,
  }

  if (!utmDataString) return trackingParameters

  try {
    const params = new URLSearchParams(utmDataString)
    trackingParameters.src = params.get("src")
    trackingParameters.sck = params.get("sck")
    trackingParameters.utm_source = params.get("utm_source")
    trackingParameters.utm_campaign = params.get("utm_campaign")
    trackingParameters.utm_medium = params.get("utm_medium")
    trackingParameters.utm_content = params.get("utm_content")
    trackingParameters.utm_term = params.get("utm_term")

    // Ensure empty strings become null
    Object.keys(trackingParameters).forEach((key) => {
      if (trackingParameters[key] === "") {
        trackingParameters[key] = null
      }
    })
  } catch (e) {
    console.error("[v0] Error extracting UTMs. Input string:", utmDataString, "Error:", e)
  }

  return trackingParameters
}

function formatDateToUTC(date: Date): string {
  const year = date.getUTCFullYear()
  const month = String(date.getUTCMonth() + 1).padStart(2, "0")
  const day = String(date.getUTCDate()).padStart(2, "0")
  const hours = String(date.getUTCHours()).padStart(2, "0")
  const minutes = String(date.getUTCMinutes()).padStart(2, "0")
  const seconds = String(date.getUTCSeconds()).padStart(2, "0")
  return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`
}

export async function GET() {
  return NextResponse.json({
    status: "ok",
    message: "PrivatePay webhook endpoint is accessible",
    timestamp: new Date().toISOString(),
  })
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()

    console.log("[v0] ========================================")
    console.log("[v0] 🔔 WEBHOOK RECEIVED FROM PRIVATEPAY")
    console.log("[v0] ========================================")
    console.log("[v0] Full payload:", JSON.stringify(body, null, 2))

    const transaction = body.data || body
    const transactionId = transaction.id
    const status = transaction.status
    const amountInCents = transaction.amount || 0
    const customer = transaction.customer || {}
    const metadata = transaction.metadata || {}
    const items = transaction.items || []
    const product = items[0] || {}
    const createdAt = transaction.createdAt || new Date().toISOString()
    const paidAt = transaction.paidAt
    const fee = transaction.fee || {}

    console.log("[v0] Transaction ID:", transactionId)
    console.log("[v0] Status:", status)
    console.log("[v0] Amount (cents):", amountInCents)
    console.log("[v0] Customer:", customer)
    console.log("[v0] Metadata:", metadata)
    console.log("[v0] Items:", items)

    let utmifyStatus: "waiting_payment" | "paid" | "refused" | "refunded" | "chargedback"
    if (status === "pending" || status === "waiting_payment") {
      utmifyStatus = "waiting_payment"
    } else if (status === "paid" || status === "approved") {
      utmifyStatus = "paid"
    } else if (status === "refused" || status === "canceled") {
      utmifyStatus = "refused"
    } else if (status === "refunded") {
      utmifyStatus = "refunded"
    } else if (status === "chargedback") {
      utmifyStatus = "chargedback"
    } else {
      console.log("[v0] ⏭️ Ignoring status:", status)
      return NextResponse.json({ ok: true, message: "Status not tracked" })
    }

    const utmDataString = metadata.utm_data || ""
    console.log("[v0] UTM data string from metadata:", utmDataString)
    const trackingParameters = extractUtmParamsRobust(utmDataString)
    console.log("[v0] Extracted tracking parameters:", trackingParameters)

    const createdDate = new Date(createdAt)
    const createdAtUTC = formatDateToUTC(createdDate)
    const approvedDateUTC = paidAt
      ? formatDateToUTC(new Date(paidAt))
      : utmifyStatus === "paid"
        ? formatDateToUTC(new Date())
        : null
    const refundedAtUTC = utmifyStatus === "refunded" ? formatDateToUTC(new Date()) : null

    const utmifyOrder = {
      orderId: transactionId,
      platform: "VakinhaCheckout",
      paymentMethod: "pix",
      status: utmifyStatus,
      createdAt: createdAtUTC,
      approvedDate: approvedDateUTC,
      refundedAt: refundedAtUTC,
      customer: {
        name: customer.name || metadata.customerName || "João Lucas",
        email: customer.email || metadata.customerEmail || "produtoonline@gmail.com",
        phone: customer.phone || "11991560063",
        document: customer.document?.number || "43887057481",
        country: "BR",
        ip: transaction.ip || null,
      },
      products: [
        {
          id: product.externalRef || "produto-online",
          name: product.title || "Produto Online",
          planId: null,
          planName: null,
          quantity: product.quantity || 1,
          priceInCents: product.unitPrice || amountInCents,
        },
      ],
      trackingParameters: trackingParameters,
      commission: {
        totalPriceInCents: amountInCents,
        gatewayFeeInCents: fee.estimatedFee || 0,
        // Se não tiver fee, envia o valor total. Se tiver fee mas resultar em 0, envia o total também
        userCommissionInCents: (fee.estimatedFee && amountInCents - fee.estimatedFee > 0) 
          ? amountInCents - fee.estimatedFee 
          : amountInCents,
        currency: "BRL",
      },
      isTest: false,
    }

    console.log("[v0] ========================================")
    console.log("[v0] 📤 SENDING ORDER TO UTMIFY")
    console.log("[v0] ========================================")
    console.log("[v0] UTMify payload:", JSON.stringify(utmifyOrder, null, 2))

    const utmifyResponse = await fetch("https://api.utmify.com.br/api-credentials/orders", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-token": UTMIFY_API_TOKEN,
      },
      body: JSON.stringify(utmifyOrder),
    })

    const responseStatusCode = utmifyResponse.status
    const responseText = await utmifyResponse.text()

    console.log("[v0] ========================================")
    console.log("[v0] 📥 UTMIFY RESPONSE")
    console.log("[v0] ========================================")
    console.log("[v0] Status Code:", responseStatusCode)
    console.log("[v0] Response Body:", responseText)

    let utmifyData: any
    try {
      utmifyData = JSON.parse(responseText)
    } catch (e) {
      utmifyData = { message: responseText }
    }

    if (!utmifyResponse.ok) {
      console.error("[v0] ========================================")
      console.error("[v0] ❌ UTMIFY ERROR")
      console.error("[v0] ========================================")
      console.error("[v0] Falha UTMify:", responseStatusCode, "-", responseText)
      console.error("[v0] Full error data:", utmifyData)
    } else {
      console.log("[v0] ========================================")
      console.log("[v0] ✅ ORDER REGISTERED IN UTMIFY!")
      console.log("[v0] ========================================")
      console.log("[v0] Success response:", utmifyData)
    }

    // Always return 200 to PrivatePay to avoid retries
    return NextResponse.json({ ok: true, transactionId, utmifyStatus: responseStatusCode, utmifyResponse: utmifyData })
  } catch (error) {
    console.error("[v0] ========================================")
    console.error("[v0] ❌ CRITICAL WEBHOOK ERROR")
    console.error("[v0] ========================================")
    console.error("[v0] Error:", error)
    // Return 200 to avoid PrivatePay retries
    return NextResponse.json({ ok: true, error: "Internal processing error" })
  }
}
