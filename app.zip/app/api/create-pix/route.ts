import { type NextRequest, NextResponse } from "next/server"

const PRIVATEPAY_BASE_URL = "https://api.privatepayclub.com/functions/v1"
const SECRET_KEY = "sk_live_pn17SqEewXRlxT7UQNqJF69kM7laUVdjIvuGeYVKWcAhTfzN"
const COMPANY_ID = "ab1c3834-aa97-4465-86df-cae25b5605de"
const UTMIFY_API_KEY = "RdkidYJtAZkF4kmdNi7USxBNCUxAFWSatTQJ"
const UTMIFY_PIXEL_ID = "68af2343ae2b5e5689381f86"
const PRODUCT_NAME = "emagrecimento"

const DEFAULT_DOCUMENT = "43887057481" // Valid CPF format for testing
const DEFAULT_PHONE = "11991560063" // Realistic phone format

export async function POST(request: NextRequest) {
  try {
    const { amount, name, email, phone, document, utmData } = await request.json()

    if (!amount || amount <= 0) {
      return NextResponse.json({ error: "Valor inválido" }, { status: 400 })
    }

    const credentials = Buffer.from(`${SECRET_KEY}:${COMPANY_ID}`).toString("base64")
    const authHeader = `Basic ${credentials}`

    console.log("[v0] ========================================")
    console.log("[v0] 🔧 CREATING PIX TRANSACTION")
    console.log("[v0] ========================================")
    console.log("[v0] Amount:", amount, "BRL")
    console.log("[v0] Customer:", name)
    console.log("[v0] UTM Data received:", utmData)

    const appUrl = process.env.NEXT_PUBLIC_APP_URL
    let postbackUrl: string

    if (appUrl) {
      const cleanAppUrl = appUrl.trim().endsWith("/") ? appUrl.trim().slice(0, -1) : appUrl.trim()
      // Ensure URL has protocol
      if (!cleanAppUrl.startsWith("http://") && !cleanAppUrl.startsWith("https://")) {
        postbackUrl = `https://${cleanAppUrl}/api/webhook/privatepay`
      } else {
        postbackUrl = `${cleanAppUrl}/api/webhook/privatepay`
      }
      console.log("[v0] Using NEXT_PUBLIC_APP_URL webhook:", postbackUrl)
    } else {
      const origin = request.headers.get("origin")
      const referer = request.headers.get("referer")

      if (origin) {
        postbackUrl = `${origin}/api/webhook/privatepay`
        console.log("[v0] Using origin webhook:", postbackUrl)
      } else if (referer) {
        const refererUrl = new URL(referer)
        postbackUrl = `${refererUrl.protocol}//${refererUrl.host}/api/webhook/privatepay`
        console.log("[v0] Using referer webhook:", postbackUrl)
      } else {
        postbackUrl = "https://pagamento-vakinha.vercel.app/api/webhook/privatepay"
        console.warn("[v0] ⚠️ Using fallback webhook URL")
      }
    }

    console.log("[v0] Final webhook URL:", postbackUrl)

    const amountInCents = Math.round(amount * 100)

    const requestBody = {
      amount: amountInCents,
      installments: 1,
      paymentMethod: "PIX",
      postbackUrl: postbackUrl,
      metadata: {
        utm_data: utmData || "",
        customerName: name || "João Lucas",
        customerEmail: email || "emagrecenatural@gmail.com",
        amount: amount,
      },
      customer: {
        name: name || "João Lucas",
        email: email || "emagrecenatural@gmail.com",
        phone: (phone || DEFAULT_PHONE).replace(/\D/g, ""),
        document: {
          number: (document || DEFAULT_DOCUMENT).replace(/\D/g, ""),
          type: "CPF",
        },
        address: {
          street: "Travessa Júlio",
          streetNumber: "880",
          zipCode: "49228463",
          neighborhood: "Jardim Santa Cruz",
          city: "Laura do Descoberto",
          state: "CE",
          country: "BR",
        },
      },
      items: [
        {
          externalRef: "produto-online",
          title: "Produto Online",
          unitPrice: amountInCents,
          quantity: 1,
          tangible: false,
        },
      ],
    }

    console.log("[v0] Request body metadata:", requestBody.metadata)

    const response = await fetch(`${PRIVATEPAY_BASE_URL}/transactions`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: authHeader,
      },
      body: JSON.stringify(requestBody),
    })

    console.log("[v0] PrivatePay response status:", response.status)

    if (!response.ok) {
      const errorText = await response.text()
      console.error("[v0] PrivatePay API Error:", errorText)

      try {
        const errorData = JSON.parse(errorText)
        if (errorData.refusedReason) {
          console.error("[v0] Refused Reason:", errorData.refusedReason.description || errorData.refusedReason)
        }
      } catch (e) {
        // Ignore parse errors
      }

      return NextResponse.json(
        { error: "Erro ao gerar PIX", detail: errorText, status: response.status },
        { status: response.status },
      )
    }

    const data = await response.json()
    console.log("[v0] PrivatePay Success! Transaction ID:", data.id)

    if (!data.pix || !data.pix.qrcode) {
      console.error("[v0] PIX QR Code not generated!")
      if (data.refusedReason) {
        console.error("[v0] Refused Reason:", data.refusedReason.description || data.refusedReason)
      }
      return NextResponse.json(
        {
          error: "PIX não foi gerado",
          detail: data.refusedReason?.description || "QR Code não disponível",
          transactionId: data.id,
          status: data.status,
        },
        { status: 400 },
      )
    }

    const qrCodeString = data.pix.qrcode
    const qrCodeImageUrl = `https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${encodeURIComponent(qrCodeString)}`

    return NextResponse.json({
      qrCode: qrCodeString,
      qrCodeImage: qrCodeImageUrl,
      txid: data.id,
      amount: amount,
      expiresAt: data.pix.expirationDate,
      receiptUrl: data.pix.receiptUrl,
      end2EndId: data.pix.end2EndId,
    })
  } catch (error) {
    console.error("[v0] Erro ao processar pagamento PIX:", error)
    return NextResponse.json(
      { error: "Erro interno do servidor", detail: error instanceof Error ? error.message : String(error) },
      { status: 500 },
    )
  }
}
