import { PixCheckout } from "@/components/pix-checkout"

export default function Home() {
  return (
    <main className="min-h-screen bg-gray-50 py-0">
      <PixCheckout />
    </main>
  )
}
